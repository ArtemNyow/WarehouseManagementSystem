﻿Imports System.Data.OleDb
Imports System.Windows.Forms
Imports System.Windows.Forms.DataVisualization.Charting

Public Class AnalyticsForm
    Inherits Form

    Private connectionString As String = MainForm.connectionString

    Private chartDemand As Chart
    Private chartAccuracy As Chart
    Private numAlpha As NumericUpDown
    Private numMu As NumericUpDown
    Private lblLambda, lblUtilization, lblL, lblW, lblLq, lblWq, lblMu As Label

    Public Sub New()
        MyBase.New()
        Me.Text = "Математичні моделі"
        Me.Size = New Size(1000, 800)
        Me.StartPosition = FormStartPosition.CenterScreen
        InitializeLayout()
        LoadAnalyticsData()
    End Sub

    Private Sub InitializeLayout()
        Dim layout As New TableLayoutPanel With {
            .Dock = DockStyle.Fill,
            .RowCount = 3,
            .ColumnCount = 1,
            .CellBorderStyle = TableLayoutPanelCellBorderStyle.Single,
            .Padding = New Padding(8)
        }
        layout.RowStyles.Add(New RowStyle(SizeType.Percent, 40))
        layout.RowStyles.Add(New RowStyle(SizeType.Percent, 30))
        layout.RowStyles.Add(New RowStyle(SizeType.Percent, 30))

        ' Demand Forecast
        chartDemand = CreateChart("Прогноз попиту (Exponential Smoothing)")
        Dim gbForecast As New GroupBox With {.Text = "📈 Прогноз попиту", .Dock = DockStyle.Fill}
        gbForecast.Controls.Add(chartDemand)
        layout.Controls.Add(gbForecast, 0, 0)

        ' Accuracy Chart
        chartAccuracy = CreateChart("Точність прогнозу (MAPE)")
        Dim gbAccuracy As New GroupBox With {.Text = "🎯 Точність прогнозу", .Dock = DockStyle.Fill}
        gbAccuracy.Controls.Add(chartAccuracy)
        layout.Controls.Add(gbAccuracy, 0, 1)

        ' Queueing Model
        Dim gbQueue As New GroupBox With {.Text = "📊 Модель масового обслуговування (M/M/1)", .Dock = DockStyle.Fill}
        Dim pnlQueue As New FlowLayoutPanel With {.Dock = DockStyle.Fill, .AutoScroll = True, .Padding = New Padding(10)}

        pnlQueue.Controls.Add(New Label With {.Text = "Інтенсивність обслуговування (μ):", .AutoSize = True})
        numMu = New NumericUpDown With {.Minimum = 0.1D, .Maximum = 1000, .DecimalPlaces = 2, .Value = 10, .Increment = 1}
        AddHandler numMu.ValueChanged, AddressOf OnParamChanged
        pnlQueue.Controls.Add(numMu)

        lblLambda = New Label With {.AutoSize = True, .Margin = New Padding(20, 0, 0, 0)}
        lblUtilization = New Label With {.AutoSize = True}
        lblL = New Label With {.AutoSize = True}
        lblW = New Label With {.AutoSize = True}
        lblLq = New Label With {.AutoSize = True}
        lblWq = New Label With {.AutoSize = True}

        pnlQueue.Controls.AddRange({lblLambda, lblUtilization, lblL, lblW, lblLq, lblWq})
        gbQueue.Controls.Add(pnlQueue)
        layout.Controls.Add(gbQueue, 0, 2)

        ' Forecast parameter
        numAlpha = New NumericUpDown With {.Minimum = 0.1D, .Maximum = 1D, .DecimalPlaces = 2, .Increment = 0.05D, .Value = 0.3D, .Visible = False}
        AddHandler numAlpha.ValueChanged, AddressOf OnParamChanged
        Me.Controls.Add(numAlpha)

        Me.Controls.Add(layout)
    End Sub

    Private Function CreateChart(title As String) As Chart
        Dim chart As New Chart With {.Dock = DockStyle.Fill}
        chart.ChartAreas.Add(New ChartArea())
        chart.Titles.Add(New Title(title, Docking.Top, New Font("Segoe UI", 12, FontStyle.Bold), Color.Black))
        chart.Legends.Add(New Legend())
        Return chart
    End Function

    Private Sub OnParamChanged(sender As Object, e As EventArgs)
        LoadAnalyticsData()
    End Sub

    Private Sub LoadAnalyticsData()
        Using conn As New OleDbConnection(connectionString)
            conn.Open()
            LoadDemandForecast(conn)
        End Using
        LoadQueueingModel()
    End Sub

    Private Sub LoadDemandForecast(conn As OleDbConnection)
        chartDemand.Series.Clear()
        Dim actual = New Series("Фактичний попит") With {.ChartType = SeriesChartType.Line, .Color = Color.Blue}
        Dim forecast = New Series("Прогноз") With {.ChartType = SeriesChartType.Line, .BorderDashStyle = ChartDashStyle.Dash, .Color = Color.Red}

        Dim dt As New DataTable()
        Dim adapter = New OleDbDataAdapter("SELECT arrival_time, unloaded_quantity FROM Incomes ORDER BY arrival_time", conn)
        adapter.Fill(dt)

        Dim times = dt.AsEnumerable().Select(Function(r) CDate(r("arrival_time"))).ToList()
        Dim vals = dt.AsEnumerable().Select(Function(r) CDbl(r("unloaded_quantity"))).ToList()

        Dim alpha = CDbl(numAlpha.Value)
        Dim forecasts As New List(Of Double)
        If vals.Count > 0 Then forecasts.Add(vals(0))
        For i = 1 To vals.Count - 1
            forecasts.Add(alpha * vals(i - 1) + (1 - alpha) * forecasts(i - 1))
        Next

        For i = 0 To vals.Count - 1
            actual.Points.AddXY(times(i), vals(i))
            If i > 0 Then forecast.Points.AddXY(times(i), forecasts(i))
        Next

        chartDemand.Series.Add(actual)
        chartDemand.Series.Add(forecast)
        LoadForecastAccuracy(times, vals, forecasts)
    End Sub

    Private Sub LoadForecastAccuracy(times As List(Of Date), actuals As List(Of Double), forecasts As List(Of Double))
        chartAccuracy.Series.Clear()
        Dim mape = New Series("MAPE") With {.ChartType = SeriesChartType.Column, .Color = Color.MediumVioletRed}
        For i = 1 To actuals.Count - 1
            Dim err = Math.Abs((actuals(i) - forecasts(i)) / actuals(i)) * 100
            mape.Points.AddXY(times(i), err)
        Next
        chartAccuracy.Series.Add(mape)
    End Sub

    Private Sub LoadQueueingModel()
        Using conn As New OleDbConnection(connectionString)
            conn.Open()
            Dim lambda = CDbl(New OleDbCommand("SELECT AVG(unloaded_quantity) FROM Incomes", conn).ExecuteScalar())
            Dim mu = Convert.ToDouble(numMu.Value)

            ' Перевірка на коректність μ та λ
            If mu <= 0 Then
                MessageBox.Show("μ має бути більше 0.")
                Return
            End If

            Dim rho = lambda / mu
            Dim isStable = (rho < 1)

            ' Розрахунки тільки для стабільної системи
            Dim L As Double = If(isStable, rho / (1 - rho), Double.NaN)
            Dim W As Double = If(isStable, 1 / (mu - lambda), Double.NaN)
            Dim Lq As Double = If(isStable, (rho ^ 2) / (1 - rho), Double.NaN)
            Dim Wq As Double = If(isStable, rho / (mu - lambda), Double.NaN)

            ' Відображення результатів або помилок
            lblLambda.Text = $"λ: {Math.Round(lambda, 2)}"
            lblMu.Text = $"μ: {Math.Round(mu, 2)}"
            lblUtilization.Text = $"ρ: {Math.Round(rho, 2)}" & If(Not isStable, " (система нестабільна!)", "")

            lblL.Text = If(isStable, $"L: {Math.Round(L, 2)}", "L: ∞")
            lblW.Text = If(isStable, $"W: {Math.Round(W, 2)}", "W: ∞")
            lblLq.Text = If(isStable, $"Lq: {Math.Round(Lq, 2)}", "Lq: ∞")
            lblWq.Text = If(isStable, $"Wq: {Math.Round(Wq, 2)}", "Wq: ∞")
        End Using
    End Sub
End Class